// import 'dart:math';
//
// import 'package:flutter/material.dart';
// import 'package:flutter_expandable_fab/flutter_expandable_fab.dart';
//
// void main() {
//   runApp(const MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   const MyApp({super.key});
//
//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Flutter Demo',
//       theme: ThemeData(
//         colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
//         useMaterial3: true,
//       ),
//       home: const MyHomePage(title: 'Flutter Demo Home Page'),
//     );
//   }
// }
//
// class MyHomePage extends StatefulWidget {
//   const MyHomePage({super.key, required this.title});
//   final String title;
//
//   @override
//   State<MyHomePage> createState() => _MyHomePageState();
// }
//
// class _MyHomePageState extends State<MyHomePage> with SingleTickerProviderStateMixin {
//   final _key = GlobalKey<ExpandableFabState>();
//
//   late final AnimationController _controller = AnimationController(
//     duration: const Duration(milliseconds: 2000),
//     vsync: this,
//   );
//
//   double screenWidth(context) => MediaQuery.of(context).size.width;
//   double screenHeight(context) => MediaQuery.of(context).size.height;
//   bool isFloatingOpen = false;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Stack(
//         children: [
//           const Padding(padding: EdgeInsets.only(top: 200)),
//
//           Container(
//             width: screenWidth(context),
//             height: screenHeight(context),
//             color: Colors.grey,
//           ),
//
//           Positioned(
//             right: 25,
//             bottom: 25,
//             child: SizedBox(
//               width: 56,
//               height: 56,
//               child: FloatingActionButton(
//                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
//                 heroTag: "add",
//                 backgroundColor: Colors.white,
//                 child: const Icon(Icons.add, size: 36,),
//                 onPressed: () {
//                   isFloatingOpen = !isFloatingOpen;
//                   setState(() {
//
//                   });
//                 },
//               ),
//             ),
//           ),
//
//           Positioned(
//             right: 100,
//             bottom: 25,
//             child: SizedBox(
//               width: 56,
//               height: 56,
//               child: FloatingActionButton(
//                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
//                 heroTag: "add",
//                 backgroundColor: Colors.white,
//                 child: const Icon(Icons.add, size: 36,),
//                 onPressed: () {
//                   isFloatingOpen = !isFloatingOpen;
//                   setState(() {
//
//                   });
//                 },
//               ),
//             ),
//           ),
//
//
//
//           AnimatedContainer(
//             duration: const Duration(milliseconds: 150),
//             width: isFloatingOpen ? 56 : 0,
//             height: isFloatingOpen ? 56 : 0,
//             child: FloatingActionButton(
//               heroTag: "112131",
//               backgroundColor: Colors.red,
//               onPressed: () {
//                 setState(() {});
//               },
//             ),
//           ),
//
//           const Padding(padding: EdgeInsets.only(top: 50)),
//
//
//
//         ],
//       ),
//     );
//   }
//
//
// }
import 'package:flutter/material.dart';

import 'flutter_expandable_fab.dart';

void main() {
  runApp(const MyApp());
}

final scaffoldKey = GlobalKey<ScaffoldMessengerState>();

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue,
      ),
      scaffoldMessengerKey: scaffoldKey,
      home: const FirstPage(),
    );
  }
}

class CounterWidget extends StatelessWidget {
  CounterWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return PageView(
      children: [
        Stack(
          children: [
            SizedBox.expand(
                child: Image.asset("assets/image1.png",
                  fit: BoxFit.cover,)
            ),
            Text("Flutter Page1", style: TextStyle(fontSize: 48, color: Colors.black),),
          ],
        ),
        Stack(
          children: [
            SizedBox.expand(
              child: Image.asset("assets/image2.png",
                fit: BoxFit.cover,)
            ),
            Text("Flutter Page2", style: TextStyle(fontSize: 48, color: Colors.black),),
          ],
        ),
        SizedBox.expand(
          child: Container(
            color: Colors.blue,
            child: const Center(
              child: Text(
                'Flutter Page : 3',
                style: TextStyle(fontSize: 48),
              ),
            ),
          ),
        )
      ],
    );
  }
}

class FirstPage extends StatefulWidget {
  const FirstPage({Key? key}) : super(key: key);

  @override
  State<FirstPage> createState() => _FirstPageState();
}

class _FirstPageState extends State<FirstPage> {
  final _key = GlobalKey<ExpandableFabState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CounterWidget(),
      floatingActionButtonLocation: ExpandableFab.location,
      floatingActionButton: ExpandableFab(
        key: _key,
        // duration: const Duration(milliseconds: 500),
        // distance: 200.0,
        // type: ExpandableFabType.up,
        // pos: ExpandableFabPos.left,
        // childrenOffset: const Offset(0, 20),
        // fanAngle: 40,
        // openButtonBuilder: RotateFloatingActionButtonBuilder(
        //   child: const Icon(Icons.abc),
        //   fabSize: ExpandableFabSize.large,
        //   foregroundColor: Colors.amber,
        //   backgroundColor: Colors.green,
        //   shape: const CircleBorder(),
        //   angle: 3.14 * 2,
        // ),
        // closeButtonBuilder: FloatingActionButtonBuilder(
        //   size: 56,
        //   builder: (BuildContext context, void Function()? onPressed,
        //       Animation<double> progress) {
        //     return IconButton(
        //       onPressed: onPressed,
        //       icon: const Icon(
        //         Icons.check_circle_outline,
        //         size: 40,
        //       ),
        //     );
        //   },
        // ),
        // overlayStyle: ExpandableFabOverlayStyle(
        //   // color: Colors.black.withOpacity(0.5),
        //   blur: 5,
        // ),
        onOpen: () {
          debugPrint('onOpen');
        },
        afterOpen: () {
          debugPrint('afterOpen');
        },
        onClose: () {
          debugPrint('onClose');
        },
        afterClose: () {
          debugPrint('afterClose');
        },
        children: [
          FloatingActionButton.small(
            shape: const CircleBorder(),
            heroTag: null,
            child: const Icon(Icons.edit),
            onPressed: () {
              const SnackBar snackBar = SnackBar(
                content: Text("SnackBar"),
              );
              scaffoldKey.currentState?.showSnackBar(snackBar);
            },
          ),
          FloatingActionButton.small(
            shape: const CircleBorder(),
            heroTag: null,
            child: const Icon(Icons.search),
            onPressed: () {

            },
          ),
          FloatingActionButton.small(
            shape: const CircleBorder(),
            heroTag: null,
            child: const Icon(Icons.share),
            onPressed: () {
              final state = _key.currentState;
              if (state != null) {
                debugPrint('isOpen:${state.isOpen}');
                state.toggle();
              }
            },
          ),
        ],

      ),
    );
  }
}
